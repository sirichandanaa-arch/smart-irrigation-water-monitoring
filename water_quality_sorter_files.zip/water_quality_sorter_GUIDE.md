## Tools
- 3D printer (PETG capable)
- M3 hex key
- Small Phillips head screwdriver
- Wire strippers
- Multimeter
- Flathead screwdriver

## Assumptions
- Access to a 3D printer and PETG filament
- Basic electronics understanding
- Arduino IDE installed on a computer
- 12V DC power supply available (compatible with DC barrel jack)

## 1. Fabrication
### 1.1 3D print all enclosure and mount components
*(not yet generated)*

### 1.2 Verify fit of sensor holder inserts into the water sampling chamber
*(not yet generated)*

### 1.3 Prepare water sampling chamber for tubing connectors
*(not yet generated)*

### 1.4 Mount solenoid valve into its 3D printed mount
*(not yet generated)*

## 2. Wiring
### 2.1 Wire 12V DC power supply output to 5V buck converter input
*(not yet generated)*

### 2.2 Wire 5V buck converter output to main controller, pH, turbidity, TDS sensors, and solenoid relay module VCC/GND
*(not yet generated)*

### 2.3 Connect analog outputs of pH, turbidity, and TDS sensors to main controller ADC pins
*(not yet generated)*

### 2.4 Connect main controller GPIO to solenoid valve relay module 'IN' pin
*(not yet generated)*

### 2.5 Wire 12V power supply output to solenoid valve relay module power input
*(not yet generated)*

### 2.6 Connect solenoid valve relay module NO/COM to 12V solenoid valve
*(not yet generated)*

## 3. Bring-up
### 3.1 Verify power rails (5V and 12V) with multimeter before connecting main controller and sensors
*(not yet generated)*

### 3.2 Upload basic 'blink' firmware to main controller to verify programming functionality
*(not yet generated)*

### 3.3 Develop and upload initial firmware to read pH, turbidity, and TDS sensor analog values
*(not yet generated)*

### 3.4 Test solenoid valve relay module control by toggling the GPIO pin from the main controller
*(not yet generated)*

### 3.5 Calibrate pH, turbidity, and TDS sensors using known reference solutions (if applicable)
*(not yet generated)*

## 4. Assembly
### 4.1 Mount the electronics enclosure base and water sampling chamber to the main base plate
*(not yet generated)*

### 4.2 Mount the main controller and solenoid valve relay module to their respective mounts, then mount mounts to main base plate
*(not yet generated)*

### 4.3 Insert pH, turbidity, and TDS sensors into their holders within the water sampling chamber
*(not yet generated)*

### 4.4 Install tubing connectors into the water sampling chamber
*(not yet generated)*

### 4.5 Connect water inlet and outlet tubes to the sampling chamber and solenoid valve, securing with hose clamps
*(not yet generated)*

### 4.6 Route and secure all electrical wiring within the electronics enclosure, apply strain relief where necessary
*(not yet generated)*

### 4.7 Attach the electronics enclosure lid to the base
*(not yet generated)*

### 4.8 Perform a final system test, checking for leaks and proper water diversion
*(not yet generated)*
